
public class UserFunction extends LibraryTest{

    public void hello(String hello) {
        System.out.print(hello);
    }


    public void introduce(String introduce) {
        System.out.println(introduce);
    }

    public void explain(String explain) {
        System.out.println(explain);
    }
}

